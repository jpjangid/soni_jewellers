export const environment = {
  base_url : 'http://103.155.84.143:9071/api/',
  production: true
};
